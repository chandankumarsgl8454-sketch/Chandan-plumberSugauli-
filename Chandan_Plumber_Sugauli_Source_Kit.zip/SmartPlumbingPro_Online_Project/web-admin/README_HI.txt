WEB ADMIN PANEL — CHANDAN PLUMBER
================================
यह मोबाइल/कंप्यूटर ब्राउज़र में चलने वाला responsive web admin panel starter है।

पहले जरूरी सेटअप:
1. Firebase Console में project बनाएं या अपने मौजूदा project का उपयोग करें।
2. Project settings में Web App जोड़ें और web-admin/firebase-config.js में config values भरें।
3. Authentication > Sign-in method में Email/Password enable करें।
4. अपने admin account को भरोसेमंद server/Admin SDK से custom claim admin=true दें। Public app से admin claim कभी सेट न करें।
5. ../firebase/firestore.rules को Firestore Rules में publish करें।
6. web-admin फ़ोल्डर को HTTPS static hosting पर deploy करें (Firebase Hosting, Netlify आदि)। सीधे file:// से खोलने पर module imports काम न भी करें।

फीचर:
- Admin email/password login और admin claim check
- Service add/edit/delete
- Bookings देखना और status update करना
- मुख्य service सूची में कीमतें नहीं दिखतीं

सुरक्षा:
- Firebase config में API key होना सामान्य है; Firestore Rules और Admin claim ही permissions लागू करते हैं।
- Admin password किसी HTML/JS फ़ाइल में न लिखें।
- यह starter है, आपके Firebase project में configure/deploy होने से पहले online काम नहीं करेगा।
