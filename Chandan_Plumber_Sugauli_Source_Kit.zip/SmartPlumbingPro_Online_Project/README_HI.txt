SMART PLUMBING PRO — ADMIN PANEL SOURCE PROJECT
================================================

ब्रांड: Chandan Plumber
WhatsApp: 7992231807
भाषा: हिंदी

इस प्रोजेक्ट में:
- Android ऐप का source code
- Firebase Firestore के साथ ऑनलाइन services catalog का starter
- Admin email/password login का UI
- Admin द्वारा service जोड़ना, बदलना और हटाना
- ऑनलाइन bookings की सूची देखना
- ग्राहक की booking Firestore में सेव करने का starter
- मुख्य service list में कीमतें नहीं दिखाई जातीं

महत्वपूर्ण:
- यह source project है, तैयार APK नहीं।
- Firebase project और app configuration के बिना ऑनलाइन फीचर काम नहीं करेंगे।
- google-services.json को app/ में रखना होगा।
- Firebase Authentication में Email/Password sign-in चालू करें।
- Admin user को server-side/custom claim `admin=true` देना आवश्यक है। सिर्फ ऐप में PIN या छिपा हुआ बटन सुरक्षा नहीं है।
- firestore.rules को Firebase Console में publish करें। Rules admin claim की जाँच करती हैं।
- ग्राहक की booking के लिए name, phone, address, date, service, issue, status, createdAt फ़ील्ड इस्तेमाल होते हैं।
- APK बनाने के लिए Android Studio, Android SDK और Gradle sync की जरूरत है। इस ZIP को यहाँ compile करके APK नहीं बनाया गया है।

सेटअप के चरण:
1. ZIP extract करें और Android Studio में SmartPlumbingPro_Online_Project folder खोलें।
2. Firebase Console में नया project बनाएँ।
3. Android app package name `com.chandanplumber.smartplumbing` जोड़ें।
4. `google-services.json` डाउनलोड करके `app/` folder में रखें।
5. Firebase Authentication में Email/Password चालू करके अपना admin account बनाएँ।
6. सुरक्षित server/Admin SDK से admin account को custom claim `admin=true` दें।
7. Firebase Firestore Database बनाएँ और `firebase/firestore.rules` के नियम publish करें।
8. Gradle Sync करें और Build > Build APK(s) चलाएँ।

सुरक्षा नोट:
Admin claim सेट किए बिना booking पढ़ने और service बदलने के अधिकार नहीं मिलेंगे।
Production में admin claim केवल भरोसेमंद server/Admin SDK से सेट करें; उसे public app से कभी सेट न करें।

WEB ADMIN PANEL (नया)
--------------------
`web-admin/` में responsive browser-based Admin Panel है। पहले `web-admin/firebase-config.js` में Firebase Web App config भरें, Firebase Authentication चालू करें, admin account को trusted Admin SDK से `admin=true` custom claim दें, फिर `firebase/firestore.rules` publish करके web-admin को HTTPS hosting पर deploy करें।

यह ZIP source code bundle है, compiled APK नहीं। इस environment में Android SDK/Gradle build उपलब्ध नहीं था, इसलिए APK compile नहीं किया गया। APK बनाने के लिए Android Studio में project खोलकर Firebase config जोड़ें और Build > Build APK(s) चलाएँ।

मोबाइल-ओनली सेटअप और GitHub cloud APK build के लिए `MOBILE_ONLY_SETUP_HI.txt` पढ़ें।
GitHub Actions workflow `.github/workflows/android-apk.yml` में है। Firebase configuration के बिना build पूरा नहीं होगा।
