package com.chandanplumber.smartplumbing;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.net.URLEncoder;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PHONE = "917992231807";
    private FirebaseFirestore db;
    private final ArrayList<Map<String,Object>> services = new ArrayList<>();
    private LinearLayout body, root;
    private final int teal=Color.rgb(0,137,123), dark=Color.rgb(6,59,54);
    private boolean firebaseReady=false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { FirebaseApp.initializeApp(this); db=FirebaseFirestore.getInstance(); firebaseReady=true; }
        catch(Exception e) { firebaseReady=false; }
        loadServices();
        home();
    }
    private void loadServices() {
        services.clear();
        if(firebaseReady) {
            db.collection("services").orderBy("name").get().addOnSuccessListener(snap->{
                services.clear();
                for(com.google.firebase.firestore.DocumentSnapshot d:snap) {
                    Map<String,Object> item=d.getData();
                    if(item!=null){ item.put("_id", d.getId()); services.add(item); }
                }
                if(services.isEmpty()) addDefaults();
                else home();
            }).addOnFailureListener(e->{addDefaults(); home();});
        } else { addDefaults(); }
    }
    private void addDefaults() {
        if(!services.isEmpty()) return;
        addServiceLocal("नल की मरम्मत",100,"सामान अलग से");
        addServiceLocal("नल लगाना",150,"फिटिंग की शुरुआती कीमत");
        addServiceLocal("पाइप लीकेज रिपेयर",200,"जगह देखकर अंतिम कीमत");
        addServiceLocal("फ्लश टैंक रिपेयर",250,"पार्ट्स अलग से");
        addServiceLocal("शावर लगाना",200,"फिटिंग की शुरुआती कीमत");
        addServiceLocal("वॉश बेसिन लगाना",400,"सामान अलग से");
        addServiceLocal("गीजर इंस्टॉलेशन",500,"कनेक्शन के अनुसार");
        addServiceLocal("नया पाइप फिटिंग",500,"काम देखकर कीमत तय होगी");
    }
    private void addServiceLocal(String n,int p,String d) {
        Map<String,Object> m=new HashMap<>(); m.put("name",n);m.put("price",p);m.put("desc",d); services.add(m);
    }
    private void shell(String subtitle) {
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(246,249,248));setContentView(root);
        LinearLayout banner=new LinearLayout(this);banner.setOrientation(1);banner.setPadding(18,16,18,16);banner.setBackgroundColor(dark);
        TextView logo=new TextView(this);logo.setText("🔧  CHANDAN PLUMBER");logo.setTextSize(22);logo.setTextColor(Color.WHITE);logo.setTypeface(null,Typeface.BOLD);banner.addView(logo);
        TextView sub=new TextView(this);sub.setText(subtitle);sub.setTextSize(14);sub.setTextColor(Color.rgb(201,245,236));banner.addView(sub);root.addView(banner);
        ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(16,14,16,24);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);nav.setBackgroundColor(Color.WHITE);
        Button h=navButton("🏠 होम"), b=navButton("📅 बुकिंग"), a=navButton("🔐 Admin");
        nav.addView(h,new LinearLayout.LayoutParams(0,54,1));nav.addView(b,new LinearLayout.LayoutParams(0,54,1));nav.addView(a,new LinearLayout.LayoutParams(0,54,1));root.addView(nav);
        h.setOnClickListener(v->home());b.setOnClickListener(v->booking(null));a.setOnClickListener(v->adminLogin());
    }
    private Button navButton(String t){Button b=new Button(this);b.setText(t);b.setTextSize(11);return b;}
    private TextView txt(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(dark);t.setTextSize(size);t.setPadding(0,7,0,7);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(16);e.setPadding(12,7,12,7);e.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);e.setLayoutParams(p);return e;}
    private Button action(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,7,0,7);b.setLayoutParams(p);return b;}
    private void card(View v){v.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,8);v.setLayoutParams(p);body.addView(v);}
    private void home(){
        shell("ऑनलाइन प्लम्बिंग सर्विस • हिंदी");
        TextView hero=txt("आपके घर की Plumbing Service\\nभरोसेमंद काम • साफ कीमत • आसान बुकिंग",20,true);hero.setPadding(16,18,16,18);card(hero);
        if(!firebaseReady){TextView warn=txt("Firebase सेटअप बाकी है। अभी कैटलॉग demo mode में दिख रहा है।",13,false);card(warn);}
        body.addView(txt("हमारी प्लंबिंग सर्विस",19,true));
        for(Map<String,Object> s:services){
            LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(14,8,14,8);
            c.addView(txt(String.valueOf(s.get("name")),17,true));
            if(s.get("desc")!=null)c.addView(txt(String.valueOf(s.get("desc")),13,false));
            Button book=action("यह सर्विस बुक करें");c.addView(book);book.setOnClickListener(v->booking(String.valueOf(s.get("name"))));card(c);
        }
        body.addView(action("📅 अभी बुकिंग करें")).setOnClickListener(v->booking(null));
        
    }
    private void booking(String preset){
        shell("ऑनलाइन बुकिंग फॉर्म");
        body.addView(txt("अपनी जानकारी भरें",20,true));
        EditText name=field("आपका नाम");body.addView(name);
        EditText phone=field("मोबाइल नंबर");phone.setInputType(3);body.addView(phone);
        EditText address=field("पूरा पता / मोहल्ला");body.addView(address);
        EditText date=field("बुकिंग की तारीख और समय");body.addView(date);
        EditText issue=field("समस्या का विवरण (वैकल्पिक)");body.addView(issue);
        Spinner sp=new Spinner(this);ArrayList<String> opts=new ArrayList<>();
        for(Map<String,Object> s:services)opts.add(String.valueOf(s.get("name")));
        sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts));body.addView(txt("सर्विस चुनें",16,true));body.addView(sp);
        if(preset!=null)for(int i=0;i<services.size();i++)if(preset.equals(services.get(i).get("name")))sp.setSelection(i);
        Button submit=action("बुकिंग भेजें + WhatsApp");body.addView(submit);
        submit.setOnClickListener(v->{
            String n=name.getText().toString().trim(),p=phone.getText().toString().trim(),a=address.getText().toString().trim(),dt=date.getText().toString().trim(),is=issue.getText().toString().trim();
            if(n.isEmpty()||p.isEmpty()||a.isEmpty()||dt.isEmpty()){Toast.makeText(this,"नाम, मोबाइल, पता और समय भरें",Toast.LENGTH_LONG).show();return;}
            String sv=sp.getSelectedItem()==null?"प्लम्बिंग सर्विस":sp.getSelectedItem().toString();
            Map<String,Object> data=new HashMap<>();data.put("name",n);data.put("phone",p);data.put("address",a);data.put("date",dt);data.put("service",sv);data.put("issue",is);data.put("status","नई बुकिंग");data.put("createdAt",System.currentTimeMillis());
            if(firebaseReady) db.collection("bookings").add(data).addOnSuccessListener(ref->Toast.makeText(this,"ऑनलाइन बुकिंग सेव हो गई",Toast.LENGTH_LONG).show()).addOnFailureListener(e->Toast.makeText(this,"ऑनलाइन सेव नहीं हुआ; Firebase सेटअप जाँचें",Toast.LENGTH_LONG).show());
            String msg="नई Plumbing Booking\\nनाम: "+n+"\\nमोबाइल: "+p+"\\nपता: "+a+"\\nसमय: "+dt+"\\nसर्विस: "+sv+"\\nसमस्या: "+is;
            try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+PHONE+"?text="+URLEncoder.encode(msg,"UTF-8"))));}
            catch(Exception e){Toast.makeText(this,"WhatsApp नहीं खुल सका",Toast.LENGTH_LONG).show();}
        });
    }
    private void adminLogin(){
        LinearLayout f=new LinearLayout(this);f.setPadding(20,0,20,0);f.setOrientation(1);
        EditText email=field("Admin email");email.setInputType(33);f.addView(email);
        EditText pass=field("Admin password");pass.setInputType(129);f.addView(pass);
        new AlertDialog.Builder(this).setTitle("Admin Login").setView(f).setPositiveButton("लॉगिन",(d,w)->{
            if(!firebaseReady){Toast.makeText(this,"पहले Firebase सेटअप करें",Toast.LENGTH_LONG).show();return;}
            com.google.firebase.auth.FirebaseAuth.getInstance().signInWithEmailAndPassword(email.getText().toString().trim(),pass.getText().toString())
                .addOnSuccessListener(r->adminPanel()).addOnFailureListener(e->Toast.makeText(this,"लॉगिन असफल: Firebase Auth सेटअप जाँचें",Toast.LENGTH_LONG).show());
        }).setNegativeButton("रद्द",null).show();
    }
    private void adminPanel(){
        shell("Admin Panel • ऑनलाइन बुकिंग");
        body.addView(txt("सर्विस कैटलॉग मैनेज करें",20,true));
        Button add=action("➕ नई सर्विस जोड़ें");body.addView(add);add.setOnClickListener(v->editService(null));
        for(Map<String,Object> s:new ArrayList<>(services)){
            LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(12,8,12,8);
            c.addView(txt(String.valueOf(s.get("name")),17,true));
            Button edit=action("✏️ बदलें");c.addView(edit);edit.setOnClickListener(v->editService(s));
            Button del=action("🗑️ सर्विस हटाएँ");c.addView(del);del.setOnClickListener(v->deleteService(s));card(c);
        }
        body.addView(txt("सभी ग्राहकों की ऑनलाइन बुकिंग",20,true));
        db.collection("bookings").orderBy("createdAt",Query.Direction.DESCENDING).limit(100).get()
            .addOnSuccessListener(snap->{for(com.google.firebase.firestore.DocumentSnapshot d:snap){
                Map<String,Object> b=d.getData();if(b==null)continue;
                TextView t=txt("नाम: "+b.get("name")+"\\nमोबाइल: "+b.get("phone")+"\\nपता: "+b.get("address")+"\\nसमय: "+b.get("date")+"\\nसर्विस: "+b.get("service")+"\\nस्थिति: "+b.get("status"),14,false);
                card(t);
            }}).addOnFailureListener(e->body.addView(txt("बुकिंग पढ़ने की अनुमति नहीं। Admin role/rules सेट करें।",14,false)));
        Button logout=action("लॉगआउट");body.addView(logout);logout.setOnClickListener(v->{com.google.firebase.auth.FirebaseAuth.getInstance().signOut();home();});
    }
    private void editService(Map<String,Object> old){
        LinearLayout f=new LinearLayout(this);f.setPadding(20,0,20,0);f.setOrientation(1);
        EditText n=field("सर्विस का नाम"),d=field("विवरण");
        if(old!=null){n.setText(String.valueOf(old.get("name")));d.setText(String.valueOf(old.get("desc")));}
        f.addView(n);f.addView(d);
        new AlertDialog.Builder(this).setTitle(old==null?"नई सर्विस जोड़ें":"सर्विस बदलें").setView(f).setNegativeButton("रद्द",null).setPositiveButton("सेव",(x,y)->{
            String name=n.getText().toString().trim();
            if(name.isEmpty()){Toast.makeText(this,"सर्विस का नाम लिखें",Toast.LENGTH_SHORT).show();return;}
            Map<String,Object> item=new HashMap<>();
            item.put("name",name);item.put("desc",d.getText().toString().trim());
            Object existingId=old==null?null:old.get("_id");
            String id=existingId==null?UUID.randomUUID().toString():String.valueOf(existingId);
            db.collection("services").document(id).set(item).addOnSuccessListener(r->{
                Toast.makeText(this,"सर्विस ऑनलाइन सेव हो गई",Toast.LENGTH_SHORT).show();
                loadServices(); adminPanel();
            }).addOnFailureListener(e->Toast.makeText(this,"सेव नहीं हुआ: Firebase Admin permissions जाँचें",Toast.LENGTH_LONG).show());
        }).show();
    }
    private void deleteService(Map<String,Object> item){
        String name=String.valueOf(item.get("name"));
        new AlertDialog.Builder(this).setTitle("सर्विस हटाएँ?")
            .setMessage("क्या आप '"+name+"' सर्विस हटाना चाहते हैं?")
            .setNegativeButton("रद्द",null)
            .setPositiveButton("हटाएँ",(dialog,which)->{
                Object rawId=item.get("_id");
                if(rawId==null){Toast.makeText(this,"इस सर्विस का ऑनलाइन रिकॉर्ड नहीं मिला।",Toast.LENGTH_LONG).show();return;}
                db.collection("services").document(String.valueOf(rawId)).delete()
                    .addOnSuccessListener(v->{Toast.makeText(this,"सर्विस हटा दी गई",Toast.LENGTH_SHORT).show();loadServices();adminPanel();})
                    .addOnFailureListener(e->Toast.makeText(this,"हटाया नहीं जा सका: Admin permissions जाँचें",Toast.LENGTH_LONG).show());
            }).show();
    }

}
